char* AboutInfo="Nintendo ne podr�ava ovaj program niti ga podr�ava, a autor nije povezan ni s jednim drugim korporativnim entitetom.\r\n"
"Program je freeware i pod uvjetom \"AS IS\"...\r\n"
"Autor ne mo�e biti odgovoran za �tetu bilo koje vrste koja proizlazi iz njegove uporabe ili prisutnosti.\r\n";

char* CorruptText="Integritet dosjea ovog programa je kompromitiran.  Ili su mediji na koje je program pohranjen o�teceni ili je ne�to izmijenilo datoteku.  Poku�ajte preuzeti svje�u kopiju programa.  Mo�da bi bilo mudro skenirati virus.\r\n\r\nPokrenuti program?";
char* CorruptTitle="Datoteka je korumpirana!";
