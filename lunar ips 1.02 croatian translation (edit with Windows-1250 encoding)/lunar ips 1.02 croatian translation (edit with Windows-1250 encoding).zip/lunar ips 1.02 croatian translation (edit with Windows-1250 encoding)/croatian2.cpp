char* OrigFileText="Birajte ORIGINALNU NEMODIFICIRANU datoteku za upotrebu";
char* NewFileText="Birajte NOVU MODIFICIRANU datoteku za upotrebu";
char* NewIPSText="Birajte IPS datoteku za spremanje kao";
char* UseIPSText="Birajte IPS datoteku za koristiti";
char* PatchFileText="Birajte datoteku za zakrpu";

char* Menu_Log="Stvori datoteku && zapi�i";
char* Menu_Header="Dodaj / oduzmi SNES i zaglavlje";
char* Menu_Warnings="&Dodatna upozorenja";

char* ROMTypeList="Najce��e datoteke ROM-a\0*.smc;*.swc;*.sfc;*.nes;*.gb;*.gbc;*.gba;*.sms;*.smd;*.ngp\0Sve datoteke (*.*)\0*.*\0\0"; //*.vb;
char* IPSTypeList="IPS datoteke zakrpe (*.ips)\0*.ips\0All Files (*.*)\0*.*\0\0";

char* LipsErrorText[]={
"Nepoznata gre�ka...", "Dogodila se nepoznata gre�ka.", //0
"Nije mogu�e otvoriti datoteku za �itanje!", "Program nije mogao otvoriti datoteku za �itanje.", //1
"Nije mogu�e otvoriti datoteku za �itanje!", "Program nije mogao otvoriti datoteku za pisanje.", //2
"Datoteka je ozna�ena kao \"Samo za �itanje\"!", "Desni klik na datoteku, birajte \"Podr�ke\",\r\ni poni�tite oznaku \"Samo za �itanje\".", //3
"Gre�ka!", "Morate unijeti nastavak datoteke.", //4
"Ovo nije IPS datoteka!", "Ova datoteka nije IPS datoteka.", //5
"To je potpuno ista datoteka!", "Trebali biste doista odabrati dva RAZLI�ITA imena datoteka da biste stvorili zakrpu...", //6
"Izrada zakrpe za cijelu datoteku nije uspjela!", "Va�a izmijenjena datoteka ima promjene na ili iznad oznake 16 MB. IPS format nije u stanju rije�iti te pomake. Generirana datoteka zakrpe sadr�avat �e promjene samo ispod te to�ke.", //7
"Izrada zakrpe dovr�ena!", "IPS zakrpa je uspje�no stvorena!", //8
"okrpa zavr�eno!", "Datoteka je uspje�no pokrpana!", //9
"Datoteke su identi�ne!", "Generirana zakrpa ne�e u�initi ni�ta...", //10
"Gre�ka!", "�ao nam je, ali format zakrpe IPS ne dopu�ta skra�ivanje datoteka na veli�ine ve�e od 16 MB.", //11
"Mogu�i problem s IPS datotekom", "Datoteka je zakrpana, ali �ini se da su podaci u IPS datoteci skra�eni ili neuskladeni...", //12
"Datoteka je, me�utim, zakrpana...", "Zakrpa ne definira �to staviti u jedno ili vi�e pro�irenih podru�ja datoteke. Iako to tehni�ki nije potrebno, obi�no je znak da ste zakrpili datoteka pogre�ne veli�ine.", //13

""
};

