This is a Spanish version of Lunar IPS, translated by Carlos Romero.
If you want the regular english version of this program, you can find it at:

http://fusoya.eludevisibility.org

�2020 FuSoYa



______________________________________________________________________

 Legal Notice
______________________________________________________________________

 The Lunar IPS program (hereafter referred to as the "Software") is
 not supported by any commercial entity.

 The Software can be distributed freely for non-commercial use only. 
 No goods, services, or money can be charged for the Software in any
 form, nor may it be bundled as part of another package that is
 commercial in nature.

 The Software is provided AS IS, and its use is at your own risk.
 Anyone mentioned in this document will not be held liable for any
 damages, direct or otherwise, arising from its use or presence.
